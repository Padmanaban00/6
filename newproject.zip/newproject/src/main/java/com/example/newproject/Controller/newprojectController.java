package com.example.newproject.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class newprojectController {
	@ResponseBody
	@RequestMapping(value="/in",method=RequestMethod.GET)
	public String hello()
	{
		return "hi";
	}
	@ResponseBody
	@RequestMapping(value="/out",method=RequestMethod.GET)
	public String hi()
	{
		return "hello";
	}
}
