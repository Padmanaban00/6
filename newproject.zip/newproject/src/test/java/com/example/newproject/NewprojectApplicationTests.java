package com.example.newproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
